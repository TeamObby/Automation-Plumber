MOHIMENUL: WHAT TO BUILD, HOW TO TEST, WHAT TO SEND KEVIN (Sep 25, 2026)
Paste this whole file into your Claude, with the waterline_pipeline folder attached.

CONTEXT (short)
- WaterLine sells a missed-call service to small plumbing shops where the OWNER answers his own phone.
- The list lives in Supabase (the source of truth). GHL is where calls happen. Rules and decisions live in Notion ("LIST MODEL MASTER").
- A screener calls shops first to confirm the owner answers. Confirmed owners go to Kevin.
- All list logic must live in code in ONE GitHub repo (waterline-pipeline) + Supabase. NOT in chats and not in people's heads.
- Kevin's Claude is the single source of truth: it reviews every change against the rules and the tests below.

WHAT'S IN THE FOLDER
- supabase_v1_schema.sql     : the tables (you already ran an earlier version). Rerun it: it only ADDS the new pieces (shop_phones, owner_class, residential_class, in_call_pool, the shop_call_state view, the AI-check columns). It's safe to rerun.
- pipeline/match_rules.py     : the matching rules (tested).
- pipeline/adapters.py        : turns each tool's columns into our standard record. One small function per tool.
- pipeline/ingest.py          : puts any tool's records into the shop list WITHOUT duplicates (attach / new shop / needs check / conflict / update / skip). It uses lookups (phone, street+zip, same city), not all-pairs, so it stays fast: 2,667 records vs 17,342 shops took 14 seconds.
- pipeline/classify.py        : the list rules: owner class, residential class, value score, hot list.
- pipeline/phones.py          : which of a shop's phone numbers to screen next (multiple numbers per shop).
- tests/test_pipeline.py      : 24 tests. All must pass.
- SYSTEM_MAP.txt              : every piece, who owns it, how it connects. Read this first.
- JOB_ADS_HOTLIST_SPEC.txt    : your second job: the job-ads hot list.
- task8_tables.sql            : Task 8 tables (source_records, needs_check). Run after the schema.
- task9_phones.sql            : Task 9 rules inside the database (next_phone + updated log_call). Run after the schema.
- job_ads_table.sql           : Task 2 table (job_ads).
- supabase/functions/ghl-call/index.ts : Task 5 + 9 webhook (saves calls, switches numbers in GHL).
- supabase/ai_check_prompt.md : Task 5 AI check prompt.
- tests/test_task9.sql        : Task 9 test (run in a TEST project only).
- test_data/                  : Task 8 real-data test with the exact expected counts.
VERSION: Sep 25, 1:40am (final). If your copy has no task9_phones.sql, it is an old copy: replace it.

STEP 0. PUT IT IN GITHUB (15 min)
1. Create a private GitHub repo "waterline-pipeline". Put the folder in it. Add Kevin as owner.
2. Every change after this = a pull request. Kevin's Claude reviews it before you merge.

STEP 1. RUN THE TESTS (5 min)
   cd waterline_pipeline
   python -m tests.test_pipeline
   Expected: "24 of 24 tests passed". Screenshot it for Kevin.

STEP 1b. RUN IT ON REAL DATA (2 min)
   python -m pipeline.ingest test_data/shops_CA_licence.csv test_data/old_google_list_CA.csv old_google_list my_result.csv
   Expected counts EXACTLY: {'NEW_SHOP': 661, 'ATTACH': 1477, 'NEEDS_CHECK': 135, 'SKIP': 331, 'UPDATE': 62, 'CONFLICT': 1}
   (17,342 licensed CA shops vs 2,667 Google records, about 12 seconds.) my_result.csv should match test_data/expected_result.csv.
   Screenshot the counts for Kevin.

STEP 2. v1 FOR MONDAY (the simple path: licence list + DataForSEO only)
a) Rerun supabase_v1_schema.sql.
b) Load the California list into the shops table from ca_v2_list.csv (Kevin has it): one row per shop. Use licence_number / dial_number / owner / city / zip / tier / set_id columns as named in the schema. Keep Kevin's GHL contact IDs for shops already in GHL.
c) When Tausif's Google lookup + review files come back:
   - Run pipeline/ingest.py on the lookup results (adapter "dataforseo_maps"; each row carries shop_id, so each result is judged only against the shop that was searched).
   - Write the ATTACH rows into Supabase (the dial number = the matched listing's phone, and a source_records row per record). Put NEEDS_CHECK rows in a "needs_check" table for the web check.
   - Send Kevin the action counts.
d) Kevin's Claude scores the batch (classify.py) and gives you the batch file. You load it into the GHL Screener queue.

STEP 3. WEEK 2: THE FULL MERGE (more tools)
- Run task8_tables.sql in Supabase (adds source_records and needs_check; safe to rerun).
- Wrap ingest.py so it reads the shops (and source_records, to recognise records it has seen before) from Supabase, and writes the results back: ATTACH -> source_records + fill the shop's columns; NEW_SHOP -> insert into shops; NEEDS_CHECK / CONFLICT -> needs_check.
- Every tool (Outscraper sweep, Yelp, Facebook, Angi...) = one adapter function + one test in tests/. Nothing else changes.

STEP 4. THE NIGHTLY BATCH (week 2-3)
A scheduled job (Supabase cron or a GitHub Action), every night:
  1. If the Screener queue in GHL has fewer than about 3 days of calls, pick the next 200-300 shops by priority.
  2. Run their fresh lookups and reviews (DataForSEO API), ingest them, and send the NEEDS_CHECK rows to the AI web check.
  3. Score them with classify.py. Push the call-pool shops (and all HOT shops) into GHL, stage "Screener queue".
  4. Post a summary to Slack: batch size, attached / needs check / new, how many in the call pool, cost.

HOW KEVIN CHECKS YOUR WORK (send him these; he gives them to his Claude)
1. A screenshot of "24 of 24 tests passed".
2. The GitHub link (or a zip of the repo).
3. After each run: the action counts + a CSV export of 50 random ATTACH rows (shop_id, business_name, city, the source's name, phone, address). Kevin's Claude spot-checks them.
4. After loading Supabase: row counts per table + an export of the shop_call_state view.
Kevin's Claude compares these against the rules and the expected numbers, and tells Kevin pass/fail with the reasons.

RULES
- Never delete shops or calls. NEEDS_CHECK and NO_MATCH are kept.
- Don't change match_rules.py or classify.py without a pull request that Kevin's Claude approves. Those files ARE the business rules.
- If a result looks odd (for example many CONFLICTs), stop and send Kevin the file.
