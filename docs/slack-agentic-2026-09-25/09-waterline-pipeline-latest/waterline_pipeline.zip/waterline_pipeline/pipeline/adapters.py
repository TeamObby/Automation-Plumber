"""Column mappers: turn each tool's rows into ONE standard record shape.
Add a new tool = add one function here + one test. Nothing else changes.

Standard record keys:
  source, source_id, name, phone, phones (list), address, city, state, zip, website, category,
  searched_shop_id (the shop we searched for, if any), raw (the original row)
"""
import json


def _s(x):
    if x is None:
        return ''
    s = str(x).strip()
    return '' if s.lower() in ('nan', 'none', 'null') else s


def _std(source, source_id, name, phone, address, city, state, zip_, website, category, searched, raw, phones=None):
    ph = [p for p in ([phone] + list(phones or [])) if _s(p)]
    return dict(source=source, source_id=_s(source_id), name=_s(name), phone=_s(phone), phones=[_s(p) for p in ph],
                address=_s(address), city=_s(city), state=_s(state), zip=_s(zip_), website=_s(website),
                category=_s(category), searched_shop_id=_s(searched), raw=raw)


def dataforseo_maps(row):
    """DataForSEO SERP Google Maps item (flattened CSV row or JSON item)."""
    ai = row.get('address_info') or {}
    if isinstance(ai, str):
        try:
            ai = json.loads(ai.replace("'", '"'))
        except Exception:
            ai = {}
    return _std('google', row.get('place_id') or row.get('cid'), row.get('title'), row.get('phone'),
                row.get('address') or ai.get('address'), row.get('city') or ai.get('city'),
                row.get('state') or ai.get('region'), row.get('zip') or ai.get('zip'),
                row.get('url') or row.get('website') or row.get('domain'), row.get('category'),
                row.get('shop_id'), row)


def apify_google(row):
    return _std('google', row.get('placeId'), row.get('title'), row.get('phoneUnformatted') or row.get('phone'),
                row.get('street') or row.get('address'), row.get('city'), row.get('state'), row.get('postalCode'),
                row.get('website'), row.get('categoryName'), row.get('shop_id'), row)


def outscraper_google(row):
    return _std('google', row.get('place_id') or row.get('google_id'), row.get('name'), row.get('phone'),
                row.get('street') or row.get('address') or row.get('full_address'), row.get('city'),
                row.get('state_code') or row.get('state'), row.get('postal_code'), row.get('site') or row.get('website'),
                row.get('category') or row.get('type'), row.get('shop_id'), row)


def yelp(row):
    return _std('yelp', row.get('yelp_id') or row.get('id') or row.get('biz_id') or row.get('yelp_url') or row.get('url'),
                row.get('name') or row.get('yelp_name') or row.get('title'), row.get('phone'),
                row.get('address') or row.get('street'), row.get('city'), row.get('state'), row.get('zip') or row.get('postal_code'),
                row.get('website'), row.get('categories') or row.get('category'), row.get('shop_id'), row)


def licence_ca(row):
    """CSLB C-36 list / master row -> a licence record (source 'licence')."""
    return _std('licence', row.get('LicenseNumber') or row.get('LicenseNo'), row.get('BusinessName'),
                row.get('PhoneNumber') or row.get('BusinessPhone'), row.get('Address') or row.get('MailingAddress'),
                row.get('City'), 'CA', row.get('Zip') or row.get('ZIPCode'), '', 'C36', '', row)


def licence_tx(row):
    """TSBPE Responsible Master Plumber file row."""
    addr = ' '.join(_s(row.get(k)) for k in ('ADDR1', 'ADDR2') if _s(row.get(k)))
    return _std('licence', 'TX-' + _s(row.get('LICENSE_NBR')), row.get('PLUMB_COMPANY'), row.get('PHONE'), addr,
                row.get('CITY'), 'TX', row.get('ZIP'), '', 'RMP', '', row)


def generic(row, source):
    """Any tool already mapped to our column names (name, phone, address, city, state, zip, website, category)."""
    return _std(source, row.get('source_id') or row.get('candidate_id'), row.get('name'), row.get('phone'), row.get('address'),
                row.get('city'), row.get('state'), row.get('zip'), row.get('website'), row.get('category'),
                row.get('shop_id'), row)


def old_google_list(row):
    """Kevin's old CA Google list (columns company_name, phone, website, category, address, city, region, zip)."""
    sid = 'OLDLIST-' + (_s(row.get('phone')) or _s(row.get('company_name')))
    return _std('old_google_list', sid, row.get('company_name'), row.get('phone'), row.get('address'), row.get('city'),
                row.get('region') or 'CA', row.get('zip'), row.get('website'), row.get('category'), '', row)


ADAPTERS = {'dataforseo_maps': dataforseo_maps, 'apify_google': apify_google, 'outscraper_google': outscraper_google,
            'yelp': yelp, 'licence_ca': licence_ca, 'licence_tx': licence_tx,
            'old_google_list': old_google_list}
