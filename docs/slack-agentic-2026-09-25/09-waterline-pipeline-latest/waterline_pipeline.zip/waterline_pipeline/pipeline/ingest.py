"""INGEST: put any tool's records into the shop list WITHOUT duplicates.

For each incoming record:
  1. Seen before (same source + source_id)?  -> UPDATE that shop.
  2. Find candidate shops by LOOKUP, not by scanning everything:
       same phone  ->  same street + zip  ->  close name in the same city
     (each lookup is a dictionary lookup, so this stays fast at 100,000+ shops; it is NOT n x n)
  3. Judge each candidate with the matching rules (match_rules.judge).
       MATCH (one best shop)      -> ATTACH to that shop
       2+ shops tie as MATCH      -> CONFLICT (a person or the AI web check decides)
       NEEDS CHECK                -> NEEDS_CHECK (the web check pile)
       nothing, and it's a plumber -> NEW shop
  If the record came from a search FOR a specific shop (searched_shop_id), only that shop is judged.

Input : shops.csv (our current shops) + a source file + the adapter name
Output: actions.csv (one row per record: action, shop_id, verdict, proofs, reason)
Run   : python -m pipeline.ingest shops.csv source.csv dataforseo_maps actions.csv
"""
import csv, re, sys
from collections import defaultdict
from .match_rules import judge, digits, street, zip5, namesim
from .adapters import ADAPTERS

PLUMBING = re.compile(r'(plumb|rooter|drain|sewer|water heater|septic|pipe)', re.I)


class ShopIndex:
    def __init__(self, shops):
        self.shops = {}
        self.by_phone = defaultdict(set)
        self.by_street = defaultdict(set)
        self.by_city = defaultdict(set)
        self.by_source = {}
        for s in shops:
            self.add(s)

    def add(self, s):
        sid = s['shop_id']
        self.shops[sid] = s
        for k in ('phone_1', 'phone_2'):
            p = digits(s.get(k))
            if p:
                self.by_phone[p].add(sid)
        for extra in (s.get('other_phones') or '').split(';'):
            p = digits(extra)
            if p:
                self.by_phone[p].add(sid)
        st, z = street(s.get('address')), zip5(s.get('zip'))
        if st and z:
            self.by_street[(st, z)].add(sid)
        c = str(s.get('city') or '').strip().lower()
        if c:
            self.by_city[c].add(sid)

    def candidates(self, rec):
        found = set()
        for p in rec['phones']:
            found |= self.by_phone.get(digits(p), set())
        st, z = street(rec['address']), zip5(rec['zip']) or zip5(rec['address'])
        if st and z:
            found |= self.by_street.get((st, z), set())
        if not found:  # only then look at names in the same city (a few dozen shops, not the whole list)
            c = rec['city'].strip().lower()
            for sid in self.by_city.get(c, ()):
                s = self.shops[sid]
                if max(namesim(s.get('business_name'), rec['name']),
                       namesim(s.get('other_name'), rec['name']) if s.get('other_name') else 0) >= 0.85:
                    found.add(sid)
        return found


def ingest(shops, raw_rows, adapter, seen=None):
    """shops: list of dicts (shop_id, business_name, other_name, phone_1, phone_2, other_phones, address, city, state, zip, website)
    seen: dict (source, source_id) -> shop_id, from the source_records table."""
    idx = ShopIndex(shops)
    seen = dict(seen or {})
    out, new_n = [], 0
    for raw in raw_rows:
        rec = ADAPTERS[adapter](raw) if isinstance(adapter, str) else adapter(raw)
        key = (rec['source'], rec['source_id'])
        if rec['source_id'] and key in seen:
            out.append(dict(action='UPDATE', shop_id=seen[key], verdict='SEEN BEFORE', proofs='', reason='same source record', **_ids(rec)))
            continue
        if rec['searched_shop_id'] and rec['searched_shop_id'] in idx.shops:
            cands = {rec['searched_shop_id']}
        else:
            cands = idx.candidates(rec)
        results = []
        for sid in cands:
            s = idx.shops[sid]
            cand = dict(name=rec['name'], phone=';'.join(rec['phones']), address=rec['address'], city=rec['city'],
                        state=rec['state'], zip=rec['zip'], website=rec['website'], category=rec['category'])
            v, conf, pr, why = _judge_multi(s, cand, rec['phones'])
            results.append((sid, v, conf, pr, why))
        matches = [r for r in results if r[1] == 'MATCH']
        if len(matches) == 1 or (len(matches) > 1 and _clear_winner(matches)):
            best = sorted(matches, key=lambda r: (r[2] == 'HIGH', len(r[3])), reverse=True)[0]
            out.append(dict(action='ATTACH', shop_id=best[0], verdict='MATCH ' + best[2], proofs='+'.join(best[3]), reason=best[4], **_ids(rec)))
            if rec['source_id']:
                seen[key] = best[0]
            _learn(idx, best[0], rec)
        elif len(matches) > 1:
            out.append(dict(action='CONFLICT', shop_id=';'.join(r[0] for r in matches), verdict='MATCH x' + str(len(matches)),
                            proofs='', reason='several shops match equally', **_ids(rec)))
        elif any(r[1] == 'NEEDS CHECK' for r in results):
            r = [r for r in results if r[1] == 'NEEDS CHECK'][0]
            out.append(dict(action='NEEDS_CHECK', shop_id=r[0], verdict='NEEDS CHECK', proofs='+'.join(r[3]), reason=r[4], **_ids(rec)))
        elif rec['searched_shop_id']:
            out.append(dict(action='NO_MATCH', shop_id=rec['searched_shop_id'], verdict='NO MATCH',
                            proofs='', reason='not the shop we searched for', **_ids(rec)))
        elif PLUMBING.search(rec['category'] + ' ' + rec['name']):
            new_n += 1
            sid = 'NEW-%06d' % new_n
            idx.add(dict(shop_id=sid, business_name=rec['name'], other_name='', phone_1=rec['phone'], phone_2='',
                         address=rec['address'], city=rec['city'], state=rec['state'], zip=rec['zip'], website=rec['website']))
            if rec['source_id']:
                seen[key] = sid
            out.append(dict(action='NEW_SHOP', shop_id=sid, verdict='NO MATCH', proofs='', reason='plumber not on our list yet', **_ids(rec)))
        else:
            out.append(dict(action='SKIP', shop_id='', verdict='NO MATCH', proofs='', reason='not a plumber, no match', **_ids(rec)))
    return out


def _judge_multi(shop, cand, phones):
    """Judge once per phone the record has, keep the strongest result."""
    best = None
    for p in (phones or ['']):
        c = dict(cand, phone=p)
        r = judge(shop, c)
        rank = {'MATCH': 3, 'NEEDS CHECK': 2, 'NO MATCH': 1}.get(r[0], 0) * 10 + len(r[2])
        if best is None or rank > best[0]:
            best = (rank, r)
    return best[1]


def _clear_winner(matches):
    s = sorted(matches, key=lambda r: (r[2] == 'HIGH', len(r[3])), reverse=True)
    return (s[0][2] == 'HIGH', len(s[0][3])) > (s[1][2] == 'HIGH', len(s[1][3]))


def _learn(idx, sid, rec):
    """Remember the new phone(s) so later records from other tools find this shop by phone."""
    for p in rec['phones']:
        d = digits(p)
        if d:
            idx.by_phone[d].add(sid)


def _ids(rec):
    return dict(source=rec['source'], source_id=rec['source_id'], name=rec['name'], phone=rec['phone'], city=rec['city'])


def main(shops_csv, source_csv, adapter, out_csv):
    shops = list(csv.DictReader(open(shops_csv, newline='', encoding='utf-8')))
    rows = list(csv.DictReader(open(source_csv, newline='', encoding='utf-8')))
    out = ingest(shops, rows, adapter)
    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['action', 'shop_id', 'verdict', 'proofs', 'reason', 'source', 'source_id', 'name', 'phone', 'city'])
        w.writeheader(); w.writerows(out)
    counts = defaultdict(int)
    for r in out:
        counts[r['action']] += 1
    print(dict(counts))


if __name__ == '__main__':
    main(*sys.argv[1:5])
