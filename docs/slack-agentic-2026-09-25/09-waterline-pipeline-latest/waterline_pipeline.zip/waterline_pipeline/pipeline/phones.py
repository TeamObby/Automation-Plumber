"""Multiple phone numbers per shop (decision 28, proposed Sep 24; waiting on Kevin's OK).

One shop = one row in shops and one GHL contact. All its numbers live in shop_phones.
GHL always shows ONE "Dial Number" (the number the screener calls now) + "Other Phones" (for reference).
next_number() decides which number to screen next, or stops.

Phone record keys: number, sources (list of where it was seen), on_google_listing (bool), line_type
('mobile' | 'landline' | 'voip' | 'tollfree' | None), valid (bool or None), shared_with_other_businesses (bool),
licence_only (bool: seen only in the licence file, never advertised).
Call record keys: number, outcome ('Owner - Busy' | 'Owner - Quiet' | 'Gatekeeper' | 'Not Sure' | 'No Answer' |
'Voicemail' | 'Wrong Number' | 'Not A Plumber' | 'Do Not Call').
"""

MAX_TRIES_PER_NUMBER = 4
STOP_SHOP = {'Owner - Busy': 'owner confirmed -> Kevin', 'Owner - Quiet': 'owner confirmed -> Kevin',
             'Gatekeeper': 'gatekeeper -> out (never try another number)', 'Do Not Call': 'do not call -> out',
             'Not A Plumber': 'not a plumber -> out'}


def dialable(phones, allow_licence_only=False):
    """Numbers we're allowed to call, best first."""
    ok = [p for p in phones if p.get('valid') is not False and not p.get('shared_with_other_businesses')
          and (allow_licence_only or not p.get('licence_only'))]
    return sorted(ok, key=lambda p: (not p.get('on_google_listing'),        # 1. the Google listing number
                                     p.get('licence_only', False),          # 2. advertised before licence-only
                                     p.get('line_type') != 'mobile',        # 3. cells before other lines
                                     -len(p.get('sources') or []),          # 4. seen in more places
                                     p['number']))


def next_number(phones, calls, allow_licence_only=False):
    """Returns (number_to_dial or None, reason)."""
    for c in calls:
        if c['outcome'] in STOP_SHOP:
            return None, STOP_SHOP[c['outcome']]
    for p in dialable(phones, allow_licence_only):
        mine = [c for c in calls if c['number'] == p['number']]
        if any(c['outcome'] == 'Wrong Number' for c in mine):
            continue                                                        # dead end, try the next number
        if any(c['outcome'] == 'Not Sure' for c in mine):
            continue                                                        # unclear, try the next number
        tries = sum(c['outcome'] in ('No Answer', 'Voicemail') for c in mine)
        if tries >= MAX_TRIES_PER_NUMBER:
            continue                                                        # exhausted, try the next number
        return p['number'], f'{tries} tries so far on this number'
    return None, 'all numbers tried -> Exhausted'
