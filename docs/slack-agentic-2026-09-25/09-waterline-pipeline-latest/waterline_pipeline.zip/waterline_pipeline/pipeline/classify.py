"""The list rules as code (LIST MODEL MASTER v2.3 + COLUMN_MAP, Sep 24 2026).
Input: one shop's facts (a dict). Output: owner_class, residential_class, value (0-100), priority, hot flag, reasons.
Every rule here must match the Notion master page. Change the page and this file together, then rerun the tests.

Facts (None = unknown):
  out_reason            str or None   (franchise, 21+, not a plumber, closed, suspended, disconnected, duplicate)
  size_group            'solo' | '2-5' | '2+' | '6-20' | '21+' | None
  office_in_reviews     bool   office staff / receptionist / dispatcher / family answering, in a review from the last 2 years (quoted)
  office_on_website     bool   "call our office", an answering service, a chat receptionist
  office_phone          bool   main number is an office phone system or 1-800
  shared_phone          bool   the same number is advertised by 2+ other businesses
  total_reviews         int
  cell_main             bool   main number is a cell
  owner_answer_reviews  bool   reviews say the owner answered / came out / did the job
  owner_run_website     bool   the website says owner-operated or writes as "I"
  sole_owner_licence    bool
  home_reviews          bool   reviews about home jobs (quoted)
  home_services_website bool
  active_lead_sites     bool   ACTIVE on Angi / HomeAdvisor / Thumbtack / Google Local Services (Verified)
  commercial_mostly     bool   reviews/website mostly commercial or new construction
  commercial_name       bool
  reviews_12m           int    all review sites added up
  reviews_6m, reviews_prev6m  int
  paid_platforms        int    platforms with ACTIVE paid signs
  maps_rank             int    best position in "plumber" Google Maps searches near the shop (None = not measured)
  call_driven_work      bool   repairs / drains / water heaters / 24/7 / emergency
  years_in_business     float
  licence_trouble       bool
  rating                float
  receptionist_ad_90d   bool   a receptionist / dispatcher / CSR job ad in the last 90 days
"""
import math


def owner_class(f):
    why = []
    unlikely = []
    if f.get('office_in_reviews'): unlikely.append('office staff mentioned in reviews')
    if f.get('office_on_website'): unlikely.append('office / answering service on website')
    if f.get('office_phone'): unlikely.append('office phone system or 1-800')
    if f.get('shared_phone'): unlikely.append('number shared with other businesses')
    if (f.get('total_reviews') or 0) >= 600: unlikely.append('600+ reviews')
    if f.get('size_group') in ('6-20', '21+'): unlikely.append('6+ people')
    if unlikely:
        return 'unlikely', unlikely
    owner_signs = [n for k, n in (('cell_main', 'cell phone'), ('owner_answer_reviews', 'reviews: owner answered/did the job'),
                                  ('owner_run_website', 'owner-run website'), ('sole_owner_licence', 'sole-owner licence')) if f.get(k)]
    if f.get('size_group') in ('solo', '2-5', '2+') and owner_signs:
        return 'likely', owner_signs
    why.append('not enough signs either way')
    return 'maybe', why


def residential_class(f):
    if f.get('home_reviews') or f.get('home_services_website') or f.get('active_lead_sites'):
        return 'likely', [n for k, n in (('home_reviews', 'home-job reviews'), ('home_services_website', 'home services on website'),
                                          ('active_lead_sites', 'active on homeowner lead sites')) if f.get(k)]
    if f.get('commercial_mostly') or f.get('commercial_name'):
        return 'unlikely', ['mostly commercial' if f.get('commercial_mostly') else 'commercial-sounding name']
    return 'unsure', ['no data']


def _mid(x, full):  # missing data = middle score
    return full / 2 if x is None else None


def value(f):
    pts, why = 0.0, []
    # CALLS NOW = 70
    r12 = f.get('reviews_12m')
    s = _mid(r12, 40)
    if s is None:
        s = 40 * min(1.0, math.log1p(r12) / math.log1p(50)); why.append(f'{r12} reviews in 12 months')
    pts += s
    pp = f.get('paid_platforms')
    s = _mid(pp, 15)
    if s is None:
        s = 0 if pp == 0 else 10 if pp == 1 else 15
        if pp: why.append(f'pays for customers on {pp} platform(s)')
    pts += s
    mr = f.get('maps_rank')
    s = _mid(mr, 10)
    if s is None:
        s = 10 if mr <= 3 else 7 if mr <= 10 else 4 if mr <= 20 else 1
    pts += s
    cd = f.get('call_driven_work')
    pts += 2.5 if cd is None else (5 if cd else 1)
    # DIRECTION = 30
    a, b = f.get('reviews_6m'), f.get('reviews_prev6m')
    if a is None or b is None:
        pts += 7.5
    else:
        ratio = (a + 1) / (b + 1)
        pts += 15 if ratio >= 1.2 else 11 if ratio >= 0.8 else 6 if ratio >= 0.5 else 2
        if ratio < 0.5: why.append('reviews fading')
    y = f.get('years_in_business')
    pts += 5 if y is None else 10 if y >= 5 else 8.5 if y >= 3 else 6 if y >= 2 else 4
    if f.get('licence_trouble'):
        pts += 0; why.append('licence trouble')
    else:
        rt = f.get('rating')
        pts += 2.5 if rt is None else (5 if rt >= 4 else 2)
    return round(pts, 1), why


def evaluate(f):
    if f.get('out_reason'):
        return dict(status='out', owner_class='', residential_class='', value=0, priority=0, hot=False, reasons=f['out_reason'])
    oc, ow = owner_class(f)
    rc, rw = residential_class(f)
    v, vw = value(f)
    boost = 1.5 if f.get('size_group') in ('2-5', '2+') else 1.0
    small = f.get('size_group') in ('solo', '2-5', '2+', None)
    no_office = not (f.get('office_in_reviews') or f.get('office_on_website') or f.get('office_phone'))
    hot = bool(f.get('receptionist_ad_90d') and small and no_office)
    replacing = bool(f.get('receptionist_ad_90d') and small and not no_office)
    in_pool = (oc == 'likely' and rc == 'likely') or hot
    status = 'hot' if hot else 'call_pool' if in_pool else 'saved_for_later'
    return dict(status=status, owner_class=oc, residential_class=rc, value=v, priority=round(v * boost, 1), hot=hot,
                replacing_receptionist=replacing, reasons='; '.join(ow + rw + vw))
