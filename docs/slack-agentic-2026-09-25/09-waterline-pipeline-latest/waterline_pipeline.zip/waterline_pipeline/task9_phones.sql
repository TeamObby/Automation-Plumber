-- TASK 9: multiple phone numbers per shop (decision 28, approved by Kevin Sep 25).
-- Same rules as pipeline/phones.py. Run AFTER supabase_v1_schema.sql. Safe to run more than once. Deletes nothing.
alter table shop_phones add column if not exists on_google_listing boolean not null default false;
alter table shop_phones add column if not exists licence_only boolean not null default false;
create table if not exists settings (key text primary key, value text);
insert into settings values ('allow_licence_only_phones', 'false') on conflict (key) do nothing;  -- Kevin decides

-- Which number to screen next. Returns {"number": "+1...", "reason": "..."}; number = null means stop.
create or replace function next_phone(p_shop text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  allow_lic boolean := coalesce((select value = 'true' from settings where key = 'allow_licence_only_phones'), false);
  stop_out  text;
  r record;
  tries int;
begin
  select outcome into stop_out from calls
   where shop_id = p_shop and call_type in ('screen', 'callback')
     and outcome in ('Owner - Busy', 'Owner - Quiet', 'Gatekeeper', 'Do Not Call', 'Not A Plumber')
   order by called_at desc limit 1;
  if stop_out is not null then
    return jsonb_build_object('number', null, 'reason', 'stop: ' || stop_out);   -- gatekeeper = never try another number
  end if;
  for r in
    select phone from shop_phones
     where shop_id = p_shop and valid is not false and shared_with = 0 and (allow_lic or not licence_only)
     order by on_google_listing desc, licence_only asc, (line_type = 'mobile') desc nulls last,
              coalesce(array_length(string_to_array(nullif(sources, ''), ','), 1), 0) desc, phone
  loop
    if exists (select 1 from calls where shop_id = p_shop and call_type in ('screen', 'callback')
                 and '+1' || right(regexp_replace(dialed_number, '\D', '', 'g'), 10) = r.phone
                 and outcome in ('Wrong Number', 'Not Sure')) then
      continue;
    end if;
    select count(*) into tries from calls where shop_id = p_shop and call_type in ('screen', 'callback')
       and '+1' || right(regexp_replace(dialed_number, '\D', '', 'g'), 10) = r.phone
       and outcome in ('No Answer', 'Voicemail');
    if tries >= 4 then continue; end if;
    return jsonb_build_object('number', r.phone, 'reason', tries || ' tries so far on this number');
  end loop;
  return jsonb_build_object('number', null, 'reason', 'all numbers tried');
end $$;

-- log_call, updated for TASK 9 (replaces the version in supabase_v1_schema.sql).
create or replace function log_call(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  s        shops%rowtype;
  v_out    text := nullif(trim(p->>'outcome'), '');
  v_caller text := coalesce(nullif(p->>'caller', ''), 'unknown');
  v_type   text := coalesce(nullif(p->>'call_type', ''),
                            case when v_caller = 'kevin' then 'sales' else 'screen' end);
  v_status text;
  v_exit   text;
  v_next   jsonb;
  v_old_dial text;
begin
  select * into s from shops where shop_id = nullif(p->>'shop_id', '');
  if not found then
    select * into s from shops where ghl_contact_id = nullif(p->>'ghl_contact_id', '');
  end if;

  insert into calls (shop_id, ghl_contact_id, called_at, direction, call_type, caller, dialed_number,
                     from_number, outcome, who_answered, noise, answer_style, vm_greeting, best_time_to_call, duration_sec,
                     recording_url, transcript, raw)
  values (s.shop_id, coalesce(p->>'ghl_contact_id', s.ghl_contact_id),
          coalesce((p->>'called_at')::timestamptz, now()),
          coalesce(nullif(p->>'direction', ''), 'outbound'), v_type, v_caller,
          p->>'dialed_number', p->>'from_number', v_out, p->>'who_answered', p->>'noise',
          p->>'answer_style', p->>'vm_greeting',
          p->>'best_time_to_call', nullif(p->>'duration_sec', '')::int,
          p->>'recording_url', p->>'transcript', p);

  if s.shop_id is null then
    return jsonb_build_object('ok', true, 'matched_shop', false);   -- call kept; Claude fixes the match
  end if;

  if v_type = 'sales' then
    update shops set sales_result = coalesce(v_out, sales_result),
                     status = case when status = 'owner_confirmed' then 'with_kevin' else status end,
                     updated_at = now()
     where shop_id = s.shop_id;
  else
    v_next := next_phone(s.shop_id);   -- TASK 9: which number next (Wrong Number / 4 tries move to the next number)
    if p->>'dialed_number' is not null and v_out is not null then
      update shop_phones set screen_result = v_out
       where shop_id = s.shop_id and phone = '+1' || right(regexp_replace(p->>'dialed_number', '\D', '', 'g'), 10);
    end if;
    v_status := case
      when v_out in ('Owner - Busy', 'Owner - Quiet') then 'owner_confirmed'
      when v_out = 'Gatekeeper'                       then 'out_gatekeeper'
      when v_out = 'Not A Plumber'                    then 'disqualified'
      when v_out = 'Do Not Call'                      then 'dnc'
      when v_next->>'number' is null                  then 'exhausted'   -- every allowed number tried
      else 'screening' end;
    v_exit := case v_status
      when 'out_gatekeeper' then 'out-7g'
      when 'disqualified'   then 'not-a-plumber'
      when 'dnc'            then 'dnc'
      when 'exhausted'      then 'all-numbers-tried'
      else null end;

    v_old_dial := s.dial_number;
    update shops set
      dial_number          = case when v_status = 'screening' then coalesce(v_next->>'number', dial_number) else dial_number end,
      screen_attempts      = screen_attempts + 1,
      status               = case when status in ('with_kevin','demo_booked','customer','lost') then status else v_status end,
      exit_reason          = coalesce(v_exit, exit_reason),
      who_answered         = coalesce(nullif(p->>'who_answered', ''), who_answered),
      best_time_to_call    = coalesce(nullif(p->>'best_time_to_call', ''), best_time_to_call),
      background           = coalesce(nullif(p->>'noise', ''), background),
      answer_style         = coalesce(nullif(p->>'answer_style', ''), answer_style),
      vm_greeting          = coalesce(nullif(p->>'vm_greeting', ''), vm_greeting),
      owner_first          = coalesce(nullif(p->>'first_name', ''), owner_first),   -- name heard on the call beats the licence name
      ghl_contact_id       = coalesce(ghl_contact_id, nullif(p->>'ghl_contact_id', '')),
      first_dialed_at      = coalesce(first_dialed_at, now()),
      frozen_at_first_dial = coalesce(frozen_at_first_dial, jsonb_build_object(
                               'tier', tier, 'fit', fit, 'sure', sure, 'segment', segment,
                               'size_group', size_group, 'score_version', score_version,
                               'top_reasons', top_reasons)),
      updated_at           = now()
    where shop_id = s.shop_id;
  end if;

  return jsonb_build_object('ok', true, 'matched_shop', true, 'shop_id', s.shop_id,
    'status', v_status, 'next_number', v_next->>'number', 'next_reason', v_next->>'reason',
    'number_changed', (v_status = 'screening' and v_next->>'number' is distinct from v_old_dial));
end $$;
revoke execute on function next_phone(text) from public, anon, authenticated;
revoke execute on function log_call(jsonb) from public, anon, authenticated;
