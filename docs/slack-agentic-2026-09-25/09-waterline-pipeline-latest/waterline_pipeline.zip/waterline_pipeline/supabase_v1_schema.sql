-- WaterLine v1 database (Supabase / Postgres). Paste into Supabase > SQL Editor > Run.
-- 4 tables, 3 functions, 2 productivity views. Rules and memory live in Notion, not here.
--   shops      one row per shop. shop_id (WL-000123) is made by the database.
--   calls      one row per call (screener and Kevin), filled by the GHL webhook.
--   raw_pages  long raw text (website text, reviews, job ads, ads). Short answers go in shops.
--   sets       each batch of about 100 shops loaded into GHL (for example CA-A1-S01).
--   log_call()          the webhook calls this once per call; it writes the call and updates the shop.
--   record_ai_check()   the AI check job writes its answers here; SQL decides if it disagrees with the screener.
--   attach_transcript() adds a transcript or recording link to a call later.
--   screener_hourly / screener_daily   productivity numbers per screener.

create sequence if not exists shop_seq start 1;

create table if not exists shops (
  shop_id            text primary key default ('WL-' || lpad(nextval('shop_seq')::text, 6, '0')),
  ghl_contact_id     text unique,                 -- GHL contact ID (filled when loaded into GHL)
  shop_name          text not null,
  dial_number        text,                        -- the advertised number only, as +1XXXXXXXXXX
  city text, state text, zip text,
  timezone           text,                        -- e.g. America/Los_Angeles
  website            text,
  owner_first text, owner_last text,
  licence_number text, licence_status text,
  size_group         text,                        -- solo / 2-5 / 6-20 / unknown
  segment            text,                        -- A..I from the SEGMENT MAP
  fit text, sure text,                            -- H / M / L
  tier               int,
  score_version      text,                        -- e.g. v1
  top_reasons        text,
  missing_data       text,
  set_id             text,                        -- which batch it was loaded in
  status             text not null default 'new',
  exit_reason        text,                        -- e.g. out-7g, wrong-number, dnc
  who_answered       text,
  best_time_to_call  text,
  background         text,                        -- latest Screen Noise when someone answered
  answer_style       text,
  vm_greeting        text,                        -- latest voicemail greeting type (Mailbox full = misses calls)
  said_busy          text,                        -- from the AI check
  screen_flag        boolean not null default false, -- AI disagreed with the screener; needs a look
  owner_class        text,                        -- likely / maybe / unlikely (owner answers)   [decision 26]
  residential_class  text,                        -- likely / unsure / unlikely (home jobs)      [decision 26]
  in_call_pool       boolean generated always as (owner_class = 'likely' and residential_class = 'likely') stored,
  screen_attempts    int not null default 0,
  first_dialed_at    timestamptz,
  frozen_at_first_dial jsonb,                     -- copy of tier/fit/sure/reasons at first dial
  sales_result       text,
  customer_start date, cancel_date date, cancel_reason text,
  calls_caught_total int,
  sources            jsonb,                       -- which lists this shop came from
  extra              jsonb,                       -- any other columns we collect
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint status_ok check (status in (
    'new','queued','screening','owner_confirmed','with_kevin','demo_booked','customer','lost',
    'out_gatekeeper','disqualified','dnc','exhausted','called_before','held'))
);
create index if not exists shops_dial_idx   on shops (dial_number);
create index if not exists shops_set_idx    on shops (set_id);
create index if not exists shops_status_idx on shops (status);
create index if not exists shops_tier_idx   on shops (state, tier);

-- CALLED OR NOT: one simple answer per shop (never called / in screener queue / screened / with Kevin / out / held)
create or replace view shop_call_state as
select shop_id, shop_name, state, set_id, owner_class, residential_class, in_call_pool, status, screen_attempts, first_dialed_at,
       case when first_dialed_at is null and status in ('new','queued') then 'never called'
            when status in ('queued','screening') then 'in screener queue'
            when status = 'owner_confirmed' then 'screened: owner, waiting for Kevin'
            when status in ('with_kevin','demo_booked') then 'with Kevin'
            when status = 'customer' then 'customer'
            when status in ('out_gatekeeper','disqualified','dnc','lost','exhausted') then 'out'
            when status = 'held' then 'saved for later'
            else status end as call_state
from shops;

create table if not exists calls (
  id            bigint generated always as identity primary key,
  shop_id       text references shops (shop_id),
  ghl_contact_id text,
  called_at     timestamptz not null default now(),
  direction     text not null default 'outbound',  -- outbound / inbound
  call_type     text,                              -- screen / callback / sales
  caller        text,                              -- screener-a / screener-b / kevin
  dialed_number text,
  from_number   text,
  outcome       text,                              -- the Screener Outcome option, or Kevin's result
  who_answered  text,
  noise         text,                              -- Screen Noise / background: Job site / Driving / Home / Office / Quiet
  answer_style  text,                              -- How He Answered: Business name / His name / Just hello / Phone robot first
  vm_greeting   text,                              -- only for voicemail: Personal / Business / Carrier default / Mailbox full / Not set up
  best_time_to_call text,
  duration_sec  int,
  recording_url text,
  transcript    text,
  -- AI check (filled by the ai-check job, which reads the transcript WITHOUT seeing the screener's picks)
  ai_outcome        text,       -- same options as Screener Outcome
  ai_who_answered   text,
  ai_answer_style   text,
  ai_vm_greeting    text,
  ai_owner_name     text,       -- first name heard, if any
  ai_said_busy      text,       -- yes / no / unclear  (he said he's busy, on a job, driving, call later)
  ai_best_time      text,
  ai_mood           text,       -- rushed / normal / friendly / annoyed
  ai_confidence     text,       -- high / medium / low
  ai_reason         text,       -- one line: the words in the call that decided it
  ai_checked_at     timestamptz,
  ai_mismatch       boolean,    -- set by record_ai_check()
  flag_status       text,       -- open / ok / fixed  (Claude or Kevin closes flags)
  raw           jsonb                              -- the full webhook body, always kept
);
create index if not exists calls_shop_idx on calls (shop_id);
create index if not exists calls_time_idx on calls (called_at);
create index if not exists calls_unchecked_idx on calls (id) where ai_checked_at is null and transcript is not null;

-- Every advertised phone number found for a shop (one row per shop + number). The shop keeps ONE main dial_number.
create table if not exists shop_phones (
  id            bigint generated always as identity primary key,
  shop_id       text not null references shops (shop_id),
  phone         text not null,                 -- +1XXXXXXXXXX
  sources       text,                          -- where it's advertised: google, website, yelp, facebook, angi...
  is_main       boolean not null default false, -- the number the screener dials first (usually the Google listing's)
  line_type     text,                          -- mobile / landline / voip / tollfree (ClearoutPhone or Twilio)
  carrier       text,
  valid         boolean,
  screen_result text,                          -- outcome when this number was screened, if it was
  shared_with   int not null default 0,        -- how many OTHER shops advertise this same number (answering service / agency sign)
  unique (shop_id, phone)
);
create index if not exists shop_phones_phone_idx on shop_phones (phone);

create table if not exists raw_pages (
  id          bigint generated always as identity primary key,
  shop_id     text references shops (shop_id),
  kind        text,          -- website / google_reviews / yelp_reviews / job_ad / google_ads / lsa
  url         text,
  content     text,
  source_tool text,          -- e.g. dataforseo, apify, manual
  fetched_at  timestamptz not null default now()
);
create index if not exists raw_shop_idx on raw_pages (shop_id);

create table if not exists sets (
  set_id    text primary key,    -- e.g. CA-A1-S01, CA-RANDOM-S01
  state     text,
  tier      int,
  segment   text,
  size      int,
  loaded_at timestamptz,
  done_at   timestamptz,
  notes     text
);

-- One call in, everything updated. Body keys (all text): shop_id, ghl_contact_id, caller, call_type,
-- outcome, who_answered, noise, best_time_to_call, dialed_number, from_number, duration_sec,
-- recording_url, transcript, called_at. Unknown keys are kept in calls.raw.
create or replace function log_call(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  s        shops%rowtype;
  v_out    text := nullif(trim(p->>'outcome'), '');
  v_caller text := coalesce(nullif(p->>'caller', ''), 'unknown');
  v_type   text := coalesce(nullif(p->>'call_type', ''),
                            case when v_caller = 'kevin' then 'sales' else 'screen' end);
  v_status text;
  v_exit   text;
begin
  select * into s from shops where shop_id = nullif(p->>'shop_id', '');
  if not found then
    select * into s from shops where ghl_contact_id = nullif(p->>'ghl_contact_id', '');
  end if;

  insert into calls (shop_id, ghl_contact_id, called_at, direction, call_type, caller, dialed_number,
                     from_number, outcome, who_answered, noise, answer_style, vm_greeting, best_time_to_call, duration_sec,
                     recording_url, transcript, raw)
  values (s.shop_id, coalesce(p->>'ghl_contact_id', s.ghl_contact_id),
          coalesce((p->>'called_at')::timestamptz, now()),
          coalesce(nullif(p->>'direction', ''), 'outbound'), v_type, v_caller,
          p->>'dialed_number', p->>'from_number', v_out, p->>'who_answered', p->>'noise',
          p->>'answer_style', p->>'vm_greeting',
          p->>'best_time_to_call', nullif(p->>'duration_sec', '')::int,
          p->>'recording_url', p->>'transcript', p);

  if s.shop_id is null then
    return jsonb_build_object('ok', true, 'matched_shop', false);   -- call kept; Claude fixes the match
  end if;

  if v_type = 'sales' then
    update shops set sales_result = coalesce(v_out, sales_result),
                     status = case when status = 'owner_confirmed' then 'with_kevin' else status end,
                     updated_at = now()
     where shop_id = s.shop_id;
  else
    v_status := case
      when v_out in ('Owner - Busy', 'Owner - Quiet') then 'owner_confirmed'
      when v_out = 'Gatekeeper'                       then 'out_gatekeeper'
      when v_out in ('Wrong Number', 'Not A Plumber') then 'disqualified'
      when v_out = 'Do Not Call'                      then 'dnc'
      when s.screen_attempts + 1 >= 4                 then 'exhausted'   -- no answer / voicemail / not sure, 4th try
      else 'screening' end;
    v_exit := case v_status
      when 'out_gatekeeper' then 'out-7g'
      when 'disqualified'   then lower(replace(v_out, ' ', '-'))
      when 'dnc'            then 'dnc'
      when 'exhausted'      then 'no-answer-4x'
      else null end;

    update shops set
      screen_attempts      = screen_attempts + 1,
      status               = case when status in ('with_kevin','demo_booked','customer','lost') then status else v_status end,
      exit_reason          = coalesce(v_exit, exit_reason),
      who_answered         = coalesce(nullif(p->>'who_answered', ''), who_answered),
      best_time_to_call    = coalesce(nullif(p->>'best_time_to_call', ''), best_time_to_call),
      background           = coalesce(nullif(p->>'noise', ''), background),
      answer_style         = coalesce(nullif(p->>'answer_style', ''), answer_style),
      vm_greeting          = coalesce(nullif(p->>'vm_greeting', ''), vm_greeting),
      owner_first          = coalesce(nullif(p->>'first_name', ''), owner_first),   -- name heard on the call beats the licence name
      ghl_contact_id       = coalesce(ghl_contact_id, nullif(p->>'ghl_contact_id', '')),
      first_dialed_at      = coalesce(first_dialed_at, now()),
      frozen_at_first_dial = coalesce(frozen_at_first_dial, jsonb_build_object(
                               'tier', tier, 'fit', fit, 'sure', sure, 'segment', segment,
                               'size_group', size_group, 'score_version', score_version,
                               'top_reasons', top_reasons)),
      updated_at           = now()
    where shop_id = s.shop_id;
  end if;

  return jsonb_build_object('ok', true, 'matched_shop', true, 'shop_id', s.shop_id);
end $$;

-- Add a transcript or recording link to a call after the fact (if they arrive later than the outcome).
create or replace function attach_transcript(p_call_id bigint, p_transcript text, p_recording_url text default null)
returns void language sql security definer set search_path = public as $$
  update calls set transcript = coalesce(p_transcript, transcript),
                   recording_url = coalesce(p_recording_url, recording_url)
   where id = p_call_id;
$$;

-- Outcome groups, so "Owner - Busy" vs "Owner - Quiet" isn't counted as a disagreement.
create or replace function outcome_group(o text) returns text language sql immutable as $$
  select case
    when o in ('Owner - Busy','Owner - Quiet')   then 'owner'
    when o = 'Gatekeeper'                        then 'gatekeeper'
    when o in ('No Answer','Voicemail')          then 'no_answer'
    when o in ('Wrong Number','Not A Plumber')   then 'wrong'
    when o = 'Do Not Call'                       then 'dnc'
    when o = 'Not Sure'                          then 'unsure'
    else 'unknown' end;
$$;

-- The ai-check job calls this with the AI's answers for one call. SQL (not the AI) decides the mismatch:
-- flag when the outcome group differs and the AI is not low-confidence, or the answer style differs (high confidence).
create or replace function record_ai_check(p_call_id bigint, a jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c calls%rowtype; v_mis boolean;
begin
  select * into c from calls where id = p_call_id;
  if not found then return jsonb_build_object('ok', false, 'error', 'no such call'); end if;
  v_mis := (outcome_group(a->>'outcome') not in ('unknown','unsure')
            and outcome_group(c.outcome) <> outcome_group(a->>'outcome')
            and coalesce(a->>'confidence','low') <> 'low')
        or (coalesce(a->>'confidence','low') = 'high' and c.answer_style is not null
            and a->>'answer_style' is not null and c.answer_style <> a->>'answer_style');
  update calls set ai_outcome = a->>'outcome', ai_who_answered = a->>'who_answered',
         ai_answer_style = a->>'answer_style', ai_vm_greeting = a->>'vm_greeting',
         ai_owner_name = a->>'owner_name', ai_said_busy = a->>'said_busy', ai_best_time = a->>'best_time',
         ai_mood = a->>'mood', ai_confidence = a->>'confidence', ai_reason = a->>'reason',
         ai_checked_at = now(), ai_mismatch = v_mis,
         flag_status = case when v_mis then 'open' else flag_status end
   where id = p_call_id;
  update shops set screen_flag = screen_flag or v_mis,
         said_busy = coalesce(nullif(a->>'said_busy',''), said_busy),
         owner_first = coalesce(owner_first, nullif(a->>'owner_name','')),
         updated_at = now()
   where shop_id = c.shop_id;
  return jsonb_build_object('ok', true, 'mismatch', v_mis);
end $$;

-- PRODUCTIVITY. Every screener call is one row in calls (the screener logs an outcome on every dial,
-- including No Answer). Times are shown in Los Angeles time.
create or replace view screener_hourly as
with x as (
  select caller, called_at at time zone 'America/Los_Angeles' as t, outcome, duration_sec, ai_mismatch,
         extract(epoch from called_at - lag(called_at) over (partition by caller order by called_at)) as gap_sec
  from calls where call_type in ('screen','callback'))
select caller, date_trunc('hour', t) as hour,
       count(*)                                                     as dials,
       count(*) filter (where outcome_group(outcome) not in ('no_answer','unknown')) as answered,
       count(*) filter (where outcome_group(outcome) = 'owner')     as owners,
       count(*) filter (where outcome_group(outcome) = 'gatekeeper') as gatekeepers,
       round(avg(gap_sec) filter (where gap_sec < 900))             as avg_sec_between_dials,
       round(sum(coalesce(duration_sec,0)) / 60.0, 1)               as talk_min,
       count(*) filter (where ai_mismatch)                          as ai_flags
from x group by 1, 2;

create or replace view screener_daily as
with x as (
  select caller, called_at at time zone 'America/Los_Angeles' as t, outcome, ai_mismatch, ai_checked_at,
         extract(epoch from called_at - lag(called_at) over (partition by caller, (called_at at time zone 'America/Los_Angeles')::date order by called_at)) as gap_sec
  from calls where call_type in ('screen','callback'))
select caller, t::date as day,
       count(*)                                                        as dials,
       min(t)::time                                                    as first_dial,
       max(t)::time                                                    as last_dial,
       round(count(distinct date_trunc('minute', t) - (extract(minute from t)::int % 10) * interval '1 minute') / 6.0, 1) as active_hours,
       round(count(*) / nullif(count(distinct date_trunc('minute', t) - (extract(minute from t)::int % 10) * interval '1 minute') / 6.0, 0)) as dials_per_active_hour,
       count(*) filter (where gap_sec > 900)                           as breaks_over_15_min,
       count(*) filter (where outcome_group(outcome) not in ('no_answer','unknown')) as answered,
       count(*) filter (where outcome_group(outcome) = 'owner')        as owners,
       round(100.0 * count(*) filter (where outcome_group(outcome) = 'owner')
             / nullif(count(*) filter (where outcome_group(outcome) not in ('no_answer','unknown')), 0)) as owner_pct_of_answered,
       count(*) filter (where ai_checked_at is not null)               as ai_checked,
       count(*) filter (where ai_mismatch)                             as ai_flags,
       round(100.0 * count(*) filter (where ai_mismatch) / nullif(count(*) filter (where ai_checked_at is not null), 0)) as ai_flag_pct
from x group by 1, 2;

-- Security: tables are private. Only the webhook (service key, inside an Edge Function) and Claude's
-- connector write to them. Turn on Row Level Security with no public policies:
alter table shops     enable row level security;
alter table calls     enable row level security;
alter table raw_pages enable row level security;
alter table sets      enable row level security;
alter table shop_phones enable row level security;
revoke execute on function log_call(jsonb) from public, anon, authenticated;
revoke execute on function record_ai_check(bigint, jsonb) from public, anon, authenticated;
revoke execute on function attach_transcript(bigint, text, text) from public, anon, authenticated;
