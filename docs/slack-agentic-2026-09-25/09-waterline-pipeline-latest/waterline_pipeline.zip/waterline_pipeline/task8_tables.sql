-- TASK 8: tables for the list upload + merge program. Safe to run more than once. Never deletes anything.
create table if not exists source_records (
  id bigserial primary key,
  source text not null,              -- which tool or list: dataforseo_maps, yelp, old_google_list, licence_tx ...
  source_id text not null,           -- that tool's own id for the record (place_id, yelp id, licence number ...)
  shop_id text,                      -- the shop it was attached to (empty if not attached)
  action text not null,              -- ATTACH / NEW_SHOP / NEEDS_CHECK / CONFLICT / UPDATE / SKIP / NO_MATCH
  verdict text, proofs text, reason text,
  name text, phone text, city text, state text,
  raw jsonb,                         -- the full record exactly as the tool gave it
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  unique (source, source_id)         -- the same record can never be saved twice
);
create index if not exists source_records_shop on source_records (shop_id);

create table if not exists needs_check (
  id bigserial primary key,
  source text not null, source_id text not null,
  candidate_shop_ids text,           -- the shop(s) it might belong to
  reason text,
  raw jsonb,
  status text not null default 'open',   -- open / attached / new_shop / rejected
  resolved_shop_id text, resolved_by text, resolved_at timestamptz,
  created_at timestamptz not null default now(),
  unique (source, source_id)
);
alter table source_records enable row level security;
alter table needs_check enable row level security;
