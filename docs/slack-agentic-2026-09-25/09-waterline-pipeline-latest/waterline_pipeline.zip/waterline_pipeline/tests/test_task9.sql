-- Run in a TEST Supabase project (or a branch), never in the live one: it adds 3 fake shops.
-- Every line must end in "true". Same rules as pipeline/phones.py.
insert into shops (shop_id, shop_name, dial_number, state) values ('TEST-S1','Test One','+15550000001','CA'),('TEST-S2','Test Two','+15550000011','CA'),('TEST-S3','Test Three','+15550000021','CA');
insert into shop_phones (shop_id, phone, sources, on_google_listing, line_type, valid, shared_with, licence_only) values
 ('TEST-S1','+15550000001','google',true,'landline',true,0,false), ('TEST-S1','+15550000002','website,yelp',false,'mobile',true,0,false),
 ('TEST-S1','+15550000003','facebook',false,'landline',true,0,false), ('TEST-S1','+15550000009','licence',false,'mobile',true,0,true),
 ('TEST-S2','+15550000011','google',true,'landline',true,0,false), ('TEST-S2','+15550000019','licence',false,'mobile',true,0,true),
 ('TEST-S3','+15550000021','google',true,'landline',true,2,false), ('TEST-S3','+15550000022','website',false,'landline',true,0,false);
select 'first number = the Google listing: ' || (next_phone('TEST-S1')->>'number' = '+15550000001');
select log_call('{"shop_id":"TEST-S1","outcome":"No Answer","dialed_number":"+15550000001"}') from generate_series(1,3);
select '4th no-answer switches to the cell: ' || (r->>'next_number' = '+15550000002' and (r->>'number_changed')::boolean) from (select log_call('{"shop_id":"TEST-S1","outcome":"No Answer","dialed_number":"+15550000001"}') r) x;
select 'wrong number -> next number: ' || (r->>'next_number' = '+15550000003') from (select log_call('{"shop_id":"TEST-S1","outcome":"Wrong Number","dialed_number":"+15550000002"}') r) x;
select 'gatekeeper stops the shop: ' || (r->>'status' = 'out_gatekeeper' and r->>'next_number' is null) from (select log_call('{"shop_id":"TEST-S1","outcome":"Gatekeeper","dialed_number":"+15550000003"}') r) x;
select log_call('{"shop_id":"TEST-S2","outcome":"No Answer","dialed_number":"+15550000011"}') from generate_series(1,3);
select 'all numbers tried -> exhausted (licence-only not allowed): ' || (r->>'status' = 'exhausted') from (select log_call('{"shop_id":"TEST-S2","outcome":"No Answer","dialed_number":"+15550000011"}') r) x;
select 'shared number never dialed: ' || (next_phone('TEST-S3')->>'number' = '+15550000022');
