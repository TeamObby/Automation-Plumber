"""Run: python -m tests.test_pipeline   (from the waterline_pipeline folder). Every line must say PASS."""
import sys
sys.path.insert(0, '.')
from pipeline.ingest import ingest
from pipeline.classify import evaluate

SHOPS = [
    dict(shop_id='WL-000001', business_name='MONKEY WRENCH PLUMBING', other_name='', phone_1='6615990556', phone_2='',
         address='100 Oak St', city='Bakersfield', state='CA', zip='93301', website=''),
    dict(shop_id='WL-000002', business_name='DONALD DEVINNEY INC', other_name='DeVinney Plumbing', phone_1='7145550100', phone_2='',
         address='12 Main St', city='Huntington Beach', state='CA', zip='92648', website='devinneyplumbing.com'),
    dict(shop_id='WL-000003', business_name='ACE PLUMBING', other_name='', phone_1='5105550101', phone_2='',
         address='5 Elm St', city='Fremont', state='CA', zip='94536', website=''),
]
results = []


def check(name, cond):
    results.append(cond)
    print(('PASS ' if cond else 'FAIL ') + name)


# 1. Same phone, another name (DBA) -> ATTACH
out = ingest(SHOPS, [dict(place_id='G1', title='DeVinney Plumbing', phone='+1 714-555-0100', address='12 Main St',
                          city='Huntington Beach', state='CA', zip='92648', category='Plumber')], 'dataforseo_maps')
check('same phone + address, other name -> ATTACH to WL-000002', out[0]['action'] == 'ATTACH' and out[0]['shop_id'] == 'WL-000002')

# 2. Same name, other state -> not attached (Monkey Wrench in Massachusetts)
out = ingest(SHOPS, [dict(place_id='G2', title='Monkey Wrench Plumbing and Heating', phone='9785550199', address='1 Pine St',
                          city='Salem', state='MA', zip='01970', category='Plumber', shop_id='WL-000001')], 'dataforseo_maps')
check('same name, other state -> NO_MATCH (never attached)', out[0]['action'] == 'NO_MATCH')

# 3. Same name, same city, different phone and address -> NOT a match (the T037 lesson)
out = ingest(SHOPS, [dict(place_id='G3', title='Ace Plumbing', phone='5105559999', address='900 Far Rd', city='Fremont',
                          state='CA', zip='94538', category='Plumber')], 'dataforseo_maps')
check('same name + same city only -> NEEDS_CHECK, not ATTACH', out[0]['action'] == 'NEEDS_CHECK')

# 4. A brand-new plumber from a sweep -> NEW_SHOP, and a second tool's record of it attaches to it (no duplicate)
recs = [dict(place_id='G4', title='Zed Rooter', phone='4155550123', address='77 Bay St', city='San Francisco', state='CA',
             zip='94133', category='Plumber'),
        dict(yelp_id='Y4', name='Zed Rooter & Plumbing', phone='(415) 555-0123', address='77 Bay St', city='San Francisco',
             state='CA', zip='94133', categories='Plumbing')]
out = ingest(SHOPS, recs[:1], 'dataforseo_maps')
check('new plumber from a sweep -> NEW_SHOP', out[0]['action'] == 'NEW_SHOP')
from pipeline.adapters import dataforseo_maps, yelp
out = ingest(SHOPS, recs, lambda r: dataforseo_maps(r) if 'place_id' in r else yelp(r))
check('the same shop from Yelp -> ATTACH to the new shop (no duplicate)', out[1]['action'] == 'ATTACH' and out[1]['shop_id'] == out[0]['shop_id'])

# 5. The same record uploaded twice -> UPDATE, not a second row
out = ingest(SHOPS, recs[:1] * 2, 'dataforseo_maps')
check('same record twice -> second is UPDATE', out[1]['action'] == 'UPDATE')

# 6. Not a plumber, no match -> SKIP
out = ingest(SHOPS, [dict(place_id='G6', title='Joe Roofing', phone='3105550000', address='1 A St', city='LA', state='CA',
                          zip='90001', category='Roofing contractor')], 'dataforseo_maps')
check('non-plumber with no match -> SKIP', out[0]['action'] == 'SKIP')

# 7. Rules
e = evaluate(dict(size_group='solo', cell_main=True, home_reviews=True, reviews_12m=30))
check('solo + cell + home reviews -> call pool', e['status'] == 'call_pool' and e['owner_class'] == 'likely')
e = evaluate(dict(size_group='2-5', cell_main=True, office_in_reviews=True, home_reviews=True))
check('office staff in reviews -> unlikely owner, saved for later', e['owner_class'] == 'unlikely' and e['status'] == 'saved_for_later')
e = evaluate(dict(size_group='2-5', receptionist_ad_90d=True, home_reviews=True))
check('small + no office signs + receptionist ad -> HOT', e['status'] == 'hot')
e = evaluate(dict(size_group='2-5', receptionist_ad_90d=True, office_on_website=True))
check('small + office signs + ad -> replacing, not hot', (not e['hot']) and e['replacing_receptionist'])
e = evaluate(dict(size_group='solo', cell_main=True))
check('no home data -> residential unsure -> saved for later', e['residential_class'] == 'unsure' and e['status'] == 'saved_for_later')
e = evaluate(dict(out_reason='franchise'))
check('franchise -> out', e['status'] == 'out')
a = evaluate(dict(size_group='2-5', cell_main=True, home_reviews=True, reviews_12m=20))
b = evaluate(dict(size_group='solo', cell_main=True, home_reviews=True, reviews_12m=20))
check('same data: 2-5 shop ranks above solo (x1.5)', a['priority'] > b['priority'])
c = evaluate(dict(size_group='solo', cell_main=True, home_reviews=True))
check('missing data -> middle value (about 50)', 45 <= c['value'] <= 55)
d = evaluate(dict(size_group='solo', cell_main=True, home_reviews=True, reviews_6m=1, reviews_prev6m=10))
check('fading reviews score lower than steady', d['value'] < evaluate(dict(size_group='solo', cell_main=True, home_reviews=True, reviews_6m=10, reviews_prev6m=10))['value'])

# 8. Multiple phone numbers (pipeline/phones.py)
from pipeline.phones import next_number
PH = [dict(number='A', on_google_listing=True, line_type='landline', valid=True, sources=['google']),
      dict(number='B', line_type='mobile', valid=True, sources=['website', 'yelp']),
      dict(number='C', line_type='landline', valid=True, sources=['facebook']),
      dict(number='L', licence_only=True, line_type='mobile', valid=True, sources=['licence'])]
check('phones: Google listing number goes first', next_number(PH, [])[0] == 'A')
na4 = [dict(number='A', outcome='No Answer')] * 4
check('phones: after 4 no-answers, move to the next (the cell)', next_number(PH, na4)[0] == 'B')
check('phones: gatekeeper stops the shop, no other number', next_number(PH, [dict(number='A', outcome='Gatekeeper')])[0] is None)
check('phones: wrong number -> next number', next_number(PH, [dict(number='A', outcome='Wrong Number')])[0] == 'B')
check('phones: owner confirmed -> stop', next_number(PH, [dict(number='A', outcome='Owner - Busy')])[0] is None)
allna = [dict(number=n, outcome='No Answer') for n in 'ABC' for _ in range(4)]
check('phones: licence-only number NOT called unless Kevin allows', next_number(PH, allna)[0] is None)
check('phones: licence-only number called when allowed', next_number(PH, allna, allow_licence_only=True)[0] == 'L')
shared = [dict(number='A', on_google_listing=True, shared_with_other_businesses=True, valid=True), dict(number='B', valid=True)]
check('phones: a number shared with other businesses is never dialed', next_number(shared, [])[0] == 'B')

print(f'\n{sum(results)} of {len(results)} tests passed')
sys.exit(0 if all(results) else 1)
