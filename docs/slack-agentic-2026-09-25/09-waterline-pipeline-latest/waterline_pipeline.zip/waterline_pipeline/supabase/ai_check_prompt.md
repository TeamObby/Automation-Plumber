# AI CHECK PROMPT (used by the ai-check job, every 15 minutes)
Send ONLY the transcript, never the screener's picks. Save the JSON answer with record_ai_check(call_id, answer).

You are checking one short phone call a screener made to a plumbing shop. The screener's only goal was to find out if the OWNER answered. Use only what is in the transcript. Reply with JSON only, with these keys:
outcome: one of Owner - Busy, Owner - Quiet, Gatekeeper, No Answer, Voicemail, Not Sure, Wrong Number, Not A Plumber, Do Not Call. The owner answered = Owner - Busy if he sounded rushed or said he's on a job, driving or busy, otherwise Owner - Quiet. Anyone else answered (staff, receptionist, spouse or family, answering service, an AI receptionist in the shop's name) = Gatekeeper. A phone's own robot asking who's calling, then the owner picks up = the owner. Someone answered but you can't tell if it's the owner = Not Sure.
who_answered: Owner / Staff or receptionist / Spouse or family / Answering service / AI receptionist / Phone robot then owner / Voicemail / No answer / Wrong number
answer_style: Business name / His name / Just hello / Phone robot first / null
vm_greeting: Personal / Business / Carrier default / Mailbox full / Not set up / null
owner_name: his first name if said, else null
said_busy: yes / no / unclear
best_time: the time he gave, else null
mood: rushed / normal / friendly / annoyed / null
confidence: high / medium / low
reason: one short line quoting the words that decided it.
