// Edge Function "ghl-call": GHL sends every call result here. It saves the call and updates the shop (log_call),
// and (TASK 9) when the database says "use the shop's next number", it updates GHL.
// Deploy with JWT check OFF. Secrets: WEBHOOK_KEY (long random), GHL_TOKEN (private integration token, Waterline Growth).
// GHL webhook address: https://<project>.supabase.co/functions/v1/ghl-call?key=<WEBHOOK_KEY>
import { createClient } from "npm:@supabase/supabase-js@2";

const GHL = "https://services.leadconnectorhq.com";
const LOCATION = "rzaMhqeo2apNI1p6DG5z";                          // Waterline Growth
const PIPELINE = "CvDwpavqkHSRhg5Bn3L4";                          // Screener — Plumbers
const STAGE_ATTEMPT_1 = "7ff9193f-1e0a-4c93-9626-a6aab22b666b";
const STAGE_EXHAUSTED = "c1db8172-84bf-45a1-8f0e-5625157574a5";
const FIELD_SCREEN_ATTEMPTS = "vcqKnq23gN5wIIHqRww4";

async function ghl(path: string, method: string, body?: unknown) {
  const r = await fetch(GHL + path, {
    method,
    headers: { Authorization: `Bearer ${Deno.env.get("GHL_TOKEN")}`, Version: "2021-07-28", "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) throw new Error(`GHL ${method} ${path}: ${r.status} ${await r.text()}`);
  return r.json();
}

async function moveStage(contactId: string, stageId: string) {
  const s = await ghl(`/opportunities/search?location_id=${LOCATION}&pipeline_id=${PIPELINE}&contact_id=${contactId}`, "GET");
  const opp = s.opportunities?.[0];
  if (opp) await ghl(`/opportunities/${opp.id}`, "PUT", { pipelineStageId: stageId });
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  if (url.searchParams.get("key") !== Deno.env.get("WEBHOOK_KEY")) {
    return new Response("unauthorized", { status: 401 });
  }
  const body = await req.json();
  const p = { ...body, ...(body.customData ?? {}) };   // GHL puts our custom keys in customData
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data, error } = await sb.rpc("log_call", { p });
  if (error) return new Response(error.message, { status: 500 });

  // TASK 9: the database decided which number is next (same rules as pipeline/phones.py).
  const contactId = p.ghl_contact_id;
  try {
    if (contactId && data?.number_changed && data?.next_number) {
      // New number: dial it next, start its 4 tries from zero, back to Attempt 1.
      await ghl(`/contacts/${contactId}`, "PUT", {
        phone: data.next_number,
        customFields: [{ id: FIELD_SCREEN_ATTEMPTS, field_value: 0 }],
      });
      await moveStage(contactId, STAGE_ATTEMPT_1);
    } else if (contactId && data?.status === "exhausted") {
      await moveStage(contactId, STAGE_EXHAUSTED);   // every allowed number tried
    }
  } catch (e) {
    // The call is already saved. Log the GHL problem so Kevin's Claude can see and fix it.
    console.error(String(e));
    return Response.json({ ...data, ghl_update_error: String(e) });
  }
  return Response.json(data);
});
