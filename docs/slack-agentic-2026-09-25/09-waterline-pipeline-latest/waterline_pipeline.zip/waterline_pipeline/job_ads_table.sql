-- TASK 2: every job ad found. Safe to run more than once. Never deletes anything.
create table if not exists job_ads (
  job_id text primary key,            -- Google Jobs id (or source + url)
  title text, company text, city text, state text,
  posted_date date, source_site text, url text, description text, salary text,
  keyword text,                       -- which search found it
  is_plumbing_employer boolean,       -- after the filter
  drop_reason text,                   -- staffing agency / franchise / property manager / big contractor
  shop_id text,                       -- the shop it matched (task 8)
  result text,                        -- hot / replacing / no action / needs check
  first_seen timestamptz not null default now()
);
alter table job_ads enable row level security;
